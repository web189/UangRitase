/* ==========================================================================
   UangRitase — app.js (versi ringan)
   Perubahan utama dari versi lama:
   - Canvas particle-network (O(n²) per frame + mouse tracking) DIHAPUS
   - Interval JS yang terus-menerus membuat elemen "bubble" DIHAPUS
   - Diganti ambient blob CSS-only (lihat style.css) -> nyaris tanpa biaya CPU
   - Jumlah bintang di langit dikurangi, interval update diperlambat
   - Tabel referensi baru (galon/SPS/item/pabrik/DMS) disembunyikan di
     accordion & baru dirender saat pertama kali dibuka (lazy render)
   ========================================================================== */

/* ---------- Firebase (dimuat dinamis & aman) ----------
   Dimuat lewat import() di dalam try/catch: kalau perangkat offline dan
   modul Firebase belum tersimpan, halaman TETAP tampil memakai data yang
   disimpan di perangkat — tidak lagi layar kosong. */
const FB_VER = "11.0.0";
const FB = "https://www.gstatic.com/firebasejs/" + FB_VER + "/";
const firebaseConfig = {
  apiKey: "AIzaSyDth7CHrLlloGLKegjEzkU-jcUiWxCq828",
  authDomain: "uangritase.firebaseapp.com",
  databaseURL: "https://uangritase-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "uangritase",
  storageBucket: "uangritase.firebasestorage.app",
  messagingSenderId: "398064880612",
  appId: "1:398064880612:web:106b463bcec509d5c255f1"
};
let db = null, auth = null;
let ref, set, push, onValue, signInWithEmailAndPassword, signOut, onAuthStateChanged;
async function loadFirebase() {
  const [a, d, u] = await Promise.all([import(FB + "firebase-app.js"), import(FB + "firebase-database.js"), import(FB + "firebase-auth.js")]);
  const app = a.initializeApp(firebaseConfig);
  db = d.getDatabase(app); auth = u.getAuth(app);
  ({ ref, set, push, onValue } = d);
  ({ signInWithEmailAndPassword, signOut, onAuthStateChanged } = u);
}

/* ---------- Preferensi login (tersimpan di perangkat ini saja) ---------- */
const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
  del(k) { try { localStorage.removeItem(k); } catch (e) {} }
};

/* ---------- Cache data di perangkat (mode offline) ----------
   Setiap kali server mengirim data baru, salinannya disimpan di sini.
   Saat dibuka tanpa internet, tabel langsung terisi dari salinan terakhir. */
const CACHE_KEY = "ur_data_v17";
let lastSync = 0, dataSource = "none";   // none | cache | server | default
function saveCache() {
  store.set(CACHE_KEY, JSON.stringify({ t: Date.now(), ritase, dms: dmsList, btb: btbList }));
}
function loadCache() {
  try {
    const c = JSON.parse(store.get(CACHE_KEY) || "null");
    if (!c || !c.ritase) return false;
    ["spsAqua", "galonAqua", "spsVit", "galonVit"].forEach(k => { ritase[k] = Array.isArray(c.ritase[k]) ? c.ritase[k] : []; });
    if (Array.isArray(c.dms)) dmsList = c.dms;
    if (Array.isArray(c.btb)) btbList = c.btb;
    lastSync = c.t || 0; dataSource = "cache";
    return true;
  } catch (e) { return false; }
}
function announce(kind) {
  /* kabar untuk UI (pwa.js): kind = "server" | "cache" | "default" */
  window.dispatchEvent(new CustomEvent("ur:data", { detail: { kind, t: lastSync } }));
}

/* ---------- Helper kecil ---------- */
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const rupiah = (n) => "Rp " + Number(n).toLocaleString("id-ID");
const camel = (s) => s.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
const isVit = (s) => s.includes("vit");

/* ---------- Data default (dipakai kalau Firebase kosong) ---------- */
const DEFAULT_RITASE = {
  spsAqua: [
    ["CRG", "All SKU", 652000], ["CTR", "All SKU", 532000], ["MKS", "All SKU", 767000],
    ["CHR", "All SKU", 612000], ["KEDEP", "All SKU", 656500],
    ["CJR > 1120", "AQ 1500 ML", 943000], ["CJR > 1440", "AQ 600 ML", 943000],
    ["CJR > 840", "AQ 1500 ML", 749000], ["CJR > 960", "AQ 600 ML", 749000],
    ["CJR > 2340", "AQ 330 ML", 943000], ["CJR > 980", "AQ 1500 ML", 823000],
    ["CJR > 1820", "AQ 330 ML", 1167000], ["DEPO JONGGOL", "All SKU", 714000]
  ],
  galonAqua: [
    ["TBP", "432", 605000], ["TBP", "528", 622000], ["TBP", "720", 794000],
    ["TBP", "960", 809000], ["TBP", "1008", 820000], ["MKS", "432", 679000],
    ["MKS", "528", 696000], ["MKS", "960 LASAH", 859000], ["MKS", "960 JUGRACK", 821000],
    ["MKS", "1008", 870000], ["MKS", "720", 844000], ["CHG", "960 JUGRACK", 633000],
    ["CRG", "960 JUGRACK", 652000]
  ],
  spsVit: [
    ["TMP", "VT 200 ML", 642000], ["TMP", "VT 550 ML", 607000], ["TMP", "VT MOSKA 220", 642000],
    ["TMP", "VT 1500 ML", 630000], ["GIT", "VT 330 ML", 2163000]
  ],
  galonVit: [
    ["BTA", "528", 463000], ["BTA", "768", 574000], ["BTA", "960", 501000],
    ["SSS", "528", 457000], ["SSS", "768", 568000]
  ]
};

const DEFAULT_DMS = [
  ["9101-9100", "MEKARSARI PLANT AGM"], ["9009-9000", "SUBANG PLANT TIV"],
  ["9017-9000", "CIANJUR PLANT TIV"], ["9013-9000", "CITEUREUP PLANT TIV"],
  ["9042-9000", "TIRTA MAS PERKASA"], ["9036-9000", "TIV XWH KEDEP"],
  ["9051-9000", "GRAHAMAS INTITIRTA"], ["90A2-9000", "TGSM"],
  ["9076-9000", "SENTUL PLANT TIV"], ["9039-9000", "BUANA TIRTA ABADI"],
  ["90A3-9000", "SUMBER SUKSES SENTOSA 2"], ["90A0-9000", "CARINGIN PLANT TIV"],
  ["9105-9100", "BABAKANPARI PLANT AGM"], ["9018-9000", "CIHERANG PLANT TIV"],
  ["9059-9000", "TIV XWH CIMANGGIS"], ["9056-9000", "TML CICURUG"],
  ["9077-9000", "XWH PETUNG SARI"], ["9027-9000", "CIBINONG DC TIV"],
  ["9015-9000", "KLATEN PLANT TIV"], ["9010-9000", "WONOSOBO PLANT TIV"],
  ["90A8-9000", "BANYUWANGI PLANT TIV"], ["90AD-9000", "TIRTA MAS PERKASA BAWEN"],
  ["90A5-9000", "XWH SENTUL"]
];

/* ID counter: angka menyatu dengan kata COUNTER (tanpa spasi), mis. 281-COUNTER2 */
const fixBtbId = (s) => String(s).replace(/COUNTER\s+(\d)/gi, "COUNTER$1");

/* ---------- ID BTB DMS Counter PRG (default bila Firebase kosong) ---------- */
const DEFAULT_BTB = [
  ["281-COUNTER2", "WS PELITA DESA"],
  ["281-COUNTER3", "MT REVINA GROSIR"],
  ["281-COUNTER4", "AHS MHM"],
  ["281-COUNTER5", "TOKO RICKY"],
  ["281-COUNTER6", "TOKO AMIN SO"],
  ["281-COUNTER7", "WS YEYEN"],
  ["281-COUNTER8", "TOKO MAKMUR JAYA"],
  ["281-COUNTER9", "TOKO ASEP (SO)"],
  ["281-COUNTER10", "TOKO SELAMET"],
  ["281-COUNTER11", "IBRA WS"],
  ["281-COUNTER12", "DK TIRTA SO"],
  ["281-COUNTER13", "TOKO MEBBI GROUP"],
  ["281-COUNTER14", "TOKO MUSLIM SO"],
  ["281-COUNTER15", "TOKO AIR BERLIAN SO"],
  ["281-COUNTER16", "PT ABDULAH BANJARAN SUKSES"],
  ["281-COUNTER17", "WS ADI TIRTA"],
  ["281-COUNTER18", "TOKO RIZKI CISEENG"],
  ["281-COUNTER19", "WS SRI ALAM"],
  ["281-COUNTER20", "SARI JAYA MANDIRI SO"],
  ["281-COUNTER21", "TOKO ASA MANDIRI"],
  ["281-COUNTER22", "CV ADHI JAYA KARUNIA UTAMA"],
  ["281-COUNTER23", "TOKO PUTRA MANDIRI (SO)"]
];

/* ---------- Data referensi baru (PT. LOKON PRIMA — update 25 Mei 2026) ---------- */
/* Statis di sisi klien: tidak perlu edit admin / Firebase, murni tabel lookup. */
const REF_DATA = {
  galon: {
    label: "Kode Galon (Driver)", icon: "fa-jug-water",
    cols: ["Nama Driver", "Kode"],
    rows: [
      ["ABDUL ROHIM","281-R003"],["ADUN","281-R005"],["ANDRI KOSWARA","281-R064"],
      ["ANDRI SETIAWAN","281-R068"],["BAENURI","281-R012"],["BURHANUDIN","281-R013"],
      ["CECEP SUPRIYADI","281-R015"],["DADAN","281-R057"],["DEDE HARYANA","281-R016"],
      ["FAHRUL ROZI","281-R018"],["FIRMANSYAH","281-R051"],["GILANG","281-R045"],
      ["HERIYAWAN","281-R019"],["JAMALUDIN","281-R065"],["M JAELANI","281-R063"],
      ["MEDI","281-R022"],["MUSTOFA","281-R054"],["MUIS ISKANDAR","281-R026"],
      ["NANANG SURYANA","281-R027"],["NICANG","281-R028"],["NURUL HAQI","281-R055"],
      ["NURYADI","281-R029"],["RENDI PURNOMO","281-R031"],["SAEPULOH","281-R033"],
      ["SANUSI","281-R034"],["SARIPUDIN","281-R035"],["TEGUH KARYADI","281-R039"],
      ["TEJA SUMIRAT","281-R040"],["YAYAN","281-R067"],["WAHYU HIDAYAT","281-R042"]
    ]
  },
  sps: {
    label: "Kode SPS (Driver)", icon: "fa-truck",
    cols: ["Nama Driver", "Kode"],
    rows: [
      ["A BAHRUNI","281-R001"],["ARIS PAHRIJAL","281-R010"],["ARGI MULYANA","281-R061"],
      ["CAKRAINA","281-R014"],["FAHRI MUHAMMAD","281-R058"],["HERMANSYAH","281-R020"],
      ["IKBAL TAWAKAL","281-R043"],["INANG","281-R060"],["IRWAN","281-R044"],
      ["NAMIN","281-R062"],["LUKMANUL HAKIM","281-R021"],["M DWI CAHYANTO","281-R047"],
      ["M. CIPTAYUDIN","281-R023"],["RELY TRIGUNO","281-R030"],["REYNALDI","281-R056"],
      ["SOPIAN","281-R036"],["SUPIAN","281-R037"],["TAUFIK HIDAYAT","281-R038"]
    ]
  },
  itemUtama: {
    label: "Item Utama", icon: "fa-box",
    cols: ["Item", "Kode"],
    rows: [
      ["AQ, GALON ISI","74559"],["AQ, GALON BTL","10516937"],
      ["VT, GALON ISI","74560"],["VT, GALON BTL","10169932"],["JUGRACK","10169743"]
    ]
  },
  itemAqua: {
    label: "Item AQUA (ml)", icon: "fa-droplet",
    cols: ["Item", "Kode"],
    rows: [
      ["AQ, 200 ml","204579"],["AQ, 220 CUBE","166126"],["AQ, 330 ml","74556"],
      ["AQ, 600 ml","<span class=\"kode-strike\">74501</span> (dicoret)"],
      ["AQ, 600 GOS","208575"],["AQ, 750 ml","81681"],["AQ, 1500 ml","74553"],["PALET","10169749"]
    ]
  },
  itemVit: {
    label: "Item VIT", icon: "fa-circle",
    cols: ["Item", "Kode"],
    rows: [
      ["VT, 200","173022"],["VT, 220 MOKSA","164026"],
      ["KARTON VT","<span class=\"kode-highlight\">81714</span>"],
      ["VT, 330","112839"],["VT, 550","157095"],["VT, 1500","74565"]
    ]
  },
  itemMizz: {
    label: "Item MIZZ", icon: "fa-bottle-water",
    cols: ["Item", "Kode"],
    rows: [["MIZZ ALL 500","145141"],["MIZZ MUC","145143"],["MIZZ COCO BOS","206774"]]
  },
  dmsLevel: {
    label: "DMS Level", icon: "fa-hashtag",
    cols: ["DMS", "Kode"],
    rows: [["DMS 3","7281"],["DMS 5","9616"],["DMS 5 NG","9301"]]
  }
};
const REF_NOTE = "Pabrik BTA → keluar RB 10 · Pabrik SSS → keluar RB 15 (update 25 Mei 2026)";

/* ---------- State ---------- */
let isAdmin = false;
let logoutTimer = null, logoutSeconds = 300;
let sortState = {};
let ritase = { spsAqua: [], galonAqua: [], spsVit: [], galonVit: [] };
let dmsList = [];
let btbList = [];
let historyList = [];
let editCtx = null;      // konteks row-edit modal
let deleteCtx = null;    // konteks delete modal
let undoStack = [];
let undoTimer = null;
let resizeTimer = null;
let chatOpened = false;

/* ---------- Firebase data <-> array (hindari masalah array-sparse) ---------- */
function toObj(arr) { const o = {}; arr.forEach((r, i) => (o["r" + i] = JSON.stringify(r))); return o; }
function fromObj(o) {
  if (!o || typeof o !== "object") return [];
  return Object.keys(o).filter(k => k.startsWith("r"))
    .sort((a, b) => parseInt(a.slice(1)) - parseInt(b.slice(1)))
    .map(k => { try { return JSON.parse(o[k]); } catch { return null; } })
    .filter(Boolean);
}

/* ---------- Toast ---------- */
function toast(msg, type = "info", duration = 3200) {
  const c = $("toastContainer"); if (!c) return;
  const el = document.createElement("div");
  el.className = `toast ${type}`;
  const icon = { success: "✅", error: "❌", info: "ℹ️", warn: "⚠️" }[type] || "ℹ️";
  el.innerHTML = `<span class="toast-icon">${icon}</span><span class="toast-msg">${msg}</span>`;
  c.appendChild(el);
  requestAnimationFrame(() => el.classList.add("toast-show"));
  setTimeout(() => { el.classList.remove("toast-show"); el.classList.add("toast-hide"); setTimeout(() => el.remove(), 420); }, duration);
}
window.urToast = toast;   // dipakai pwa.js (offline / update / pasang)

/* ---------- Firebase write (v11) ----------
   Tulis per bagian (ritase/spsAqua dst). Tampilan baru berubah SETELAH server
   menerima data; kalau gagal, data di layar tidak diubah dan alasannya ditampilkan. */
const SAVE_TIMEOUT = 12000;
function explainErr(e) {
  const em = (auth && auth.currentUser && auth.currentUser.email) || "-";
  if (e && (e.code === "PERMISSION_DENIED" || /permission/i.test(e.message || ""))) return "Ditolak server: akun " + em + " tidak punya izin menulis. Masuk dengan admin@uangritase.com.";
  if (e && e.message === "timeout") return "Koneksi lambat atau offline. Data belum tersimpan, coba lagi.";
  return "Gagal menyimpan: " + ((e && e.message) || e);
}
function writeWithTimeout(path, val) {
  return Promise.race([set(ref(db, path), val), new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), SAVE_TIMEOUT))]);
}
function writeBlocked() {
  if (!auth || !db) { toast("Fitur ubah data belum siap (server belum terhubung). Coba lagi saat online.", "warn", 5000); return true; }
  if (typeof navigator !== "undefined" && navigator.onLine === false) { toast("Sedang offline. Ubah / hapus data hanya bisa saat online.", "warn", 5000); return true; }
  return false;
}
async function commitRitase(key, next) {
  if (writeBlocked()) return false;
  if (!auth.currentUser) { toast("Sesi admin habis. Masuk lagi lalu ulangi.", "warn", 5000); return false; }
  try { await writeWithTimeout("ritase/" + key, toObj(next)); ritase[key] = next; logoutSeconds = 300; return true; }
  catch (e) { toast(explainErr(e), "error", 8000); return false; }
}
async function commitBtb(next) {
  if (writeBlocked()) return false;
  if (!auth.currentUser) { toast("Sesi admin habis. Masuk lagi lalu ulangi.", "warn", 5000); return false; }
  try { await writeWithTimeout("btb", toObj(next)); btbList = next; logoutSeconds = 300; return true; }
  catch (e) { toast(explainErr(e), "error", 8000); return false; }
}
async function commitDms(next) {
  if (writeBlocked()) return false;
  if (!auth.currentUser) { toast("Sesi admin habis. Masuk lagi lalu ulangi.", "warn", 5000); return false; }
  try { await writeWithTimeout("dms", toObj(next)); dmsList = next; logoutSeconds = 300; return true; }
  catch (e) { toast(explainErr(e), "error", 8000); return false; }
}
function setBusy(btn, on) {
  if (!btn) return;
  if (on) { btn.dataset.h = btn.innerHTML; btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menyimpan…'; }
  else { btn.disabled = false; if (btn.dataset.h) btn.innerHTML = btn.dataset.h; }
}
function pushHistory(action, section, detail) {
  if (!auth || !auth.currentUser) return;
  push(ref(db, "history"), { action, section, detail, email: auth.currentUser.email, ts: Date.now() }).catch(() => {});
}

/* ---------- Stats ---------- */

/* ---------- Render tabel ritase per kategori ---------- */
const SECTION_LABEL = { "sps-aqua": "SPS AQUA", "galon-aqua": "GALON AQUA", "sps-vit": "SPS VIT", "galon-vit": "GALON VIT" };

function renderRitaseTable(id, rows) {
  const container = $(id); if (!container) return;
  const vit = isVit(id);
  const priceCls = vit ? "uang vit-price" : "uang";
  let html = `<div class="rtw"><table class="ritase-table"><thead><tr>
      <th class="th-no">#</th><th>Pabrik</th><th>Muatan</th>
      <th class="th-price">Uang Ritase</th>
      ${isAdmin ? '<th class="th-act"><i class="fas fa-sliders"></i></th>' : ""}
    </tr></thead><tbody>`;
  rows.forEach((r, i) => {
    html += `<tr class="rtr${vit ? " vit-row" : ""}" data-i="${i}">
        <td class="td-no"><span class="no-chip">${i + 1}</span></td>
        <td class="td-pabrik">${esc(r[0])}</td>
        <td class="td-muatan"><span class="muatan-chip">${esc(r[1])}</span></td>
        <td class="${priceCls}">${rupiah(r[2])}</td>
        ${isAdmin ? `<td class="td-act"><div class="act-group">
          <button class="act-btn act-edit" data-target="${id}" data-i="${i}" aria-label="Edit" title="Edit"><i class="fas fa-pen-to-square"></i><span>Edit</span></button>
          <button class="act-btn act-del" data-target="${id}" data-i="${i}" aria-label="Hapus" title="Hapus"><i class="fas fa-trash-can"></i><span>Hapus</span></button>
        </div></td>` : ""}
      </tr>`;
  });
  html += "</tbody></table></div>";
  if (isAdmin) html += `<button class="add-fab-btn" data-target="${id}"><i class="fas fa-plus-circle"></i><span>Tambah Rute ${SECTION_LABEL[id] || ""}</span></button>`;
  container.innerHTML = html;

  const wrap = container.querySelector(".rtw");
  if (wrap) requestAnimationFrame(() => { if (wrap.scrollWidth > wrap.clientWidth + 2) wrap.classList.add("scrollable"); });

  container.querySelectorAll(".rtr").forEach((tr, i) => { tr.classList.add("row-in"); });

  const countEl = $(`count-${id}`); if (countEl) countEl.textContent = `${rows.length} rute`;
  const accIt = container.closest(".acc-item");
  if (accIt && accIt.classList.contains("acc-open")) { const ab = accIt.querySelector(".acc-body"); requestAnimationFrame(() => { ab.style.maxHeight = ab.scrollHeight + "px"; }); }

  if (isAdmin) {
    container.querySelectorAll(".act-edit").forEach(b => b.addEventListener("click", e => { e.stopPropagation(); openRowEdit(b.dataset.target, +b.dataset.i); }));
    container.querySelectorAll(".act-del").forEach(b => b.addEventListener("click", e => { e.stopPropagation(); openDeleteModal("ritase", b.dataset.target, +b.dataset.i); }));
    container.querySelectorAll(".add-fab-btn").forEach(b => b.addEventListener("click", () => openRowEdit(b.dataset.target, -1)));
    enableSwipeDelete(container);
  }
  enableRowSelect(container);
}

function enableSwipeDelete(container) {
  container.querySelectorAll(".rtr").forEach(tr => {
    let startX = 0, dx = 0, dragging = false;
    tr.addEventListener("touchstart", e => { startX = e.touches[0].clientX; dx = 0; dragging = true; }, { passive: true });
    tr.addEventListener("touchmove", e => {
      if (!dragging) return;
      dx = e.touches[0].clientX - startX;
      if (dx < 0) { tr.style.transform = `translateX(${Math.max(dx, -110)}px)`; tr.style.opacity = "" + (1 + dx / 220); }
    }, { passive: true });
    tr.addEventListener("touchend", () => {
      dragging = false;
      if (dx < -75) {
        tr.style.transform = ""; tr.style.opacity = "";
        const target = tr.closest("[id]")?.id, i = +tr.dataset.i;
        setTimeout(() => openDeleteModal("ritase", target, i), 200);
      } else {
        tr.style.transition = "transform .3s,opacity .3s"; tr.style.transform = ""; tr.style.opacity = "";
        setTimeout(() => { tr.style.transition = ""; }, 320);
      }
    });
  });
}
function enableRowSelect(container) {
  container.querySelectorAll(".rtr").forEach(tr => {
    tr.addEventListener("click", e => {
      if (e.target.closest(".act-btn,.add-fab-btn")) return;
      const wasActive = tr.classList.contains("row-active");
      tr.closest("tbody").querySelectorAll(".row-active").forEach(t => t.classList.remove("row-active"));
      if (!wasActive) tr.classList.add("row-active");
    });
  });
}

function renderAllRitase() {
  renderRitaseTable("sps-aqua", ritase.spsAqua);
  renderRitaseTable("galon-aqua", ritase.galonAqua);
  renderRitaseTable("sps-vit", ritase.spsVit);
  renderRitaseTable("galon-vit", ritase.galonVit);
 
  renderAdminButton();
}

/* ---------- Row edit modal (ritase) ---------- */
function openRowEdit(target, index) {
  const key = camel(target);
  const isNew = index === -1;
  const row = isNew ? ["", "", ""] : ritase[key][index];
  editCtx = { key, target, index };
  const title = $("rowEditTitle"); if (title) title.innerHTML = isNew ? '<i class="fas fa-circle-plus"></i> Tambah Rute' : '<i class="fas fa-pen-to-square"></i> Edit Rute';
  const pill = $("rowEditSection");
  if (pill) { pill.textContent = SECTION_LABEL[target] || target; pill.className = "section-pill " + (isVit(target) ? "badge-vit" : "badge-aqua"); }
  const circle = $("editIconCircle");
  if (circle) { const vit = isVit(target); circle.style.background = vit ? "rgba(255,69,96,0.12)" : ""; circle.style.color = vit ? "var(--vit)" : ""; circle.style.borderColor = vit ? "rgba(255,69,96,0.25)" : ""; }
  $("rowEditPabrik").value = row[0]; $("rowEditMuatan").value = row[1]; $("rowEditHarga").value = row[2] || "";
  clearFieldErrors();
  openModal("rowEditModal");
  setTimeout(() => $("rowEditPabrik")?.focus(), 230);
}
async function submitRowEdit() {
  if (!editCtx || editCtx.busy) return;
  const pabrik = $("rowEditPabrik").value.trim().toUpperCase();
  const muatan = $("rowEditMuatan").value.trim().toUpperCase();
  const harga = parseInt($("rowEditHarga").value.trim(), 10);
  clearFieldErrors();
  let ok = true;
  if (!pabrik) { setFieldError("ferrPabrik", "Nama pabrik wajib diisi"); ok = false; }
  if (!muatan) { setFieldError("ferrMuatan", "Muatan wajib diisi"); ok = false; }
  if (!harga || harga <= 0) { setFieldError("ferrHarga", "Harga harus angka > 0"); ok = false; }
  if (!ok) return;
  const { key, target, index } = editCtx, isNew = index === -1;
  const next = ritase[key].map(r => [...r]);
  if (isNew) next.push([pabrik, muatan, harga]); else next[index] = [pabrik, muatan, harga];
  const btn = $("rowEditConfirm"); editCtx.busy = true; setBusy(btn, true);
  const saved = await commitRitase(key, next);
  setBusy(btn, false); if (editCtx) editCtx.busy = false;
  if (!saved) return;
  pushHistory(isNew ? "tambah" : "edit", SECTION_LABEL[target] || target, `${pabrik} · ${muatan} · ${rupiah(harga)}`);
  toast(isNew ? `Rute ditambahkan: ${pabrik}` : `Rute diperbarui: ${pabrik}`, "success");
  closeModal("rowEditModal"); editCtx = null;
  renderRitaseTable(target, ritase[key]);
  setTimeout(() => {
    const rows = document.querySelectorAll(`#${target} .rtr`), idx = isNew ? rows.length - 1 : index;
    if (rows[idx]) { rows[idx].classList.add("row-highlight"); setTimeout(() => rows[idx] && rows[idx].classList.remove("row-highlight"), 2500); }
  }, 140);
}

/* ---------- Delete + undo ---------- */
function openDeleteModal(type, target, index) {
  let label = "";
  if (type === "ritase") {
    const key = camel(target); const row = ritase[key]?.[index]; if (!row) return;
    label = `${row[0]} · ${row[1]}`; deleteCtx = { type, key, target, index, row: [...row] };
  } else {
    const row = (type === "btb" ? btbList : dmsList)[index]; if (!row) return;
    label = `${row[0]} · ${row[1]}`; deleteCtx = { type, index, row: [...row] };
  }
  const el = $("deleteLabel"); if (el) el.textContent = label;
  openModal("deleteModal");
}
async function confirmDelete() {
  if (!deleteCtx || deleteCtx.busy) return;
  const ctx = deleteCtx, { type, key, target, index, row } = ctx;
  const btn = $("deleteConfirm"); ctx.busy = true; setBusy(btn, true);
  const saved = type === "ritase"
    ? await commitRitase(key, ritase[key].filter((_, i) => i !== index))
    : type === "btb" ? await commitBtb(btbList.filter((_, i) => i !== index))
    : await commitDms(dmsList.filter((_, i) => i !== index));
  setBusy(btn, false); ctx.busy = false;
  if (!saved) return;
  undoStack.push({ type, key, target, index, row });
  deleteCtx = null; closeModal("deleteModal");
  pushHistory("hapus", type === "ritase" ? (SECTION_LABEL[target] || target) : type === "btb" ? "BTB COUNTER" : "DMS", `${row[0]} · ${row[1]}`);
  if (type === "ritase") renderRitaseTable(target, ritase[key]); else if (type === "btb") renderBtbTable(); else renderDmsTable();
  showUndoBar(`${row[0]} dihapus`);
}
function showUndoBar(msg) {
  let bar = $("undoBar");
  if (!bar) {
    bar = document.createElement("div"); bar.id = "undoBar";
    bar.innerHTML = '<span id="undoMsg"></span><button id="undoBtn"><i class="fas fa-rotate-left"></i> Pulihkan</button>';
    document.body.appendChild(bar);
    $("undoBtn").addEventListener("click", undoDelete);
  }
  $("undoMsg").textContent = msg;
  bar.classList.add("undo-show");
  clearTimeout(undoTimer);
  undoTimer = setTimeout(() => bar.classList.remove("undo-show"), 5000);
}
async function undoDelete() {
  const item = undoStack[undoStack.length - 1]; if (!item) return;
  const at = Math.min(item.index, item.type === "ritase" ? ritase[item.key].length : item.type === "btb" ? btbList.length : dmsList.length);
  let saved;
  if (item.type === "ritase") { const n = ritase[item.key].map(r => [...r]); n.splice(at, 0, item.row); saved = await commitRitase(item.key, n); }
  else if (item.type === "btb") { const n = btbList.map(r => [...r]); n.splice(at, 0, item.row); saved = await commitBtb(n); }
  else { const n = dmsList.map(r => [...r]); n.splice(at, 0, item.row); saved = await commitDms(n); }
  if (!saved) return;
  undoStack.pop(); clearTimeout(undoTimer); $("undoBar")?.classList.remove("undo-show");
  if (item.type === "ritase") renderRitaseTable(item.target, ritase[item.key]); else if (item.type === "btb") renderBtbTable(); else renderDmsTable();
  toast("Data berhasil dipulihkan", "success");
}

/* ---------- Modal helpers ---------- */
function openModal(id) { const m = $(id); if (!m) return; m.classList.remove("hidden"); requestAnimationFrame(() => m.classList.add("modal-open")); document.body.style.overflow = "hidden"; }
function closeModal(id) { const m = $(id); if (!m) return; m.classList.remove("modal-open"); setTimeout(() => { m.classList.add("hidden"); document.body.style.overflow = ""; }, 300); }
function setFieldError(id, msg) { const el = $(id); if (el) el.textContent = msg; }
function clearFieldErrors() { document.querySelectorAll(".ferr").forEach(e => e.textContent = ""); }

/* ---------- DMS table (nama lengkap pabrik) ---------- */
function renderDmsTable() {
  const tbody = document.querySelector("#dmsTable tbody"); if (!tbody) return;
  tbody.innerHTML = "";
  dmsList.forEach((row, i) => {
    const tr = document.createElement("tr");
    tr.className = "dms-row"; tr.style.animationDelay = 18 * i + "ms";
    tr.innerHTML = `
        <td class="dms-td-kode"><span class="kode-chip">${esc(row[0])}</span></td>
        <td class="dms-td-nama">${esc(row[1])}</td>
        ${isAdmin ? `<td class="td-act"><div class="act-group">
          <button class="act-btn act-edit" data-i="${i}" aria-label="Edit" title="Edit"><i class="fas fa-pen-to-square"></i><span>Edit</span></button>
          <button class="act-btn act-del" data-i="${i}" aria-label="Hapus" title="Hapus"><i class="fas fa-trash-can"></i><span>Hapus</span></button>
        </div></td>` : ""}`;
    tr.addEventListener("click", e => {
      if (e.target.closest(".act-btn")) return;
      document.querySelectorAll("#dmsTable tbody tr.active-row").forEach(t => t.classList.remove("active-row"));
      tr.classList.add("active-row");
      navigator.clipboard?.writeText(row[0]).then(() => toast(`📋 Disalin: ${row[0]} · ${row[1]}`, "info", 2200)).catch(() => {});
    });
    tbody.appendChild(tr);
    requestAnimationFrame(() => tr.classList.add("row-in"));
  });
  if (isAdmin) {
    tbody.querySelectorAll(".act-edit").forEach(b => b.addEventListener("click", e => { e.stopPropagation(); openDmsEdit(+b.dataset.i); }));
    tbody.querySelectorAll(".act-del").forEach(b => b.addEventListener("click", e => { e.stopPropagation(); openDeleteModal("dms", null, +b.dataset.i); }));
  }
  const count = $("dmsCount"); if (count) count.textContent = `${dmsList.length} pabrik`;
  const addWrap = $("dmsAddWrap"); if (addWrap) addWrap.style.display = isAdmin ? "flex" : "none";

  const headRow = document.querySelector("#dmsTable thead tr");
  if (headRow) {
    const existing = headRow.querySelector(".th-act-dms");
    if (isAdmin && !existing) { const th = document.createElement("th"); th.className = "th-act-dms th-act"; th.innerHTML = '<i class="fas fa-sliders"></i>'; headRow.appendChild(th); }
    else if (!isAdmin && existing) existing.remove();
  }
  setupDmsSearch();
}
function setupDmsSearch() {
  const input = $("searchInput"), clearBtn = $("searchClear");
  if (!input || input.dataset.ready) return;
  input.dataset.ready = "1";
  const filter = () => {
    const table = $("dmsTable"), noResult = $("noResult"), noQuery = $("noResultQuery"), count = $("dmsCount");
    if (!table) return;
    const q = input.value.toUpperCase().trim();
    const rows = Array.from(table.querySelectorAll("tbody tr"));
    let visible = 0;
    rows.forEach(tr => { const match = tr.textContent.toUpperCase().includes(q); tr.style.display = match ? "" : "none"; if (match) visible++; });
    if (clearBtn) clearBtn.style.display = q ? "flex" : "none";
    if (noResult) { noResult.classList.toggle("hidden", visible > 0 || !q); if (noQuery) noQuery.textContent = input.value; }
    if (count) count.textContent = q ? `${visible} dari ${dmsList.length} pabrik` : `${dmsList.length} pabrik`;
  };
  input.addEventListener("input", filter);
  clearBtn?.addEventListener("click", () => { input.value = ""; filter(); input.focus(); });
}
function openDmsEdit(index) {
  const isNew = index === -1;
  const row = isNew ? ["", ""] : dmsList[index];
  const title = $("dmsEditTitle"); if (title) title.innerHTML = isNew ? '<i class="fas fa-circle-plus"></i> Tambah Pabrik' : '<i class="fas fa-pen-to-square"></i> Edit Pabrik';
  $("dmsEditKode").value = row[0]; $("dmsEditNama").value = row[1]; $("dmsEditIndex").value = index;
  clearFieldErrors(); openModal("dmsEditModal");
  setTimeout(() => $("dmsEditKode")?.focus(), 230);
}
async function submitDmsEdit() {
  const kode = $("dmsEditKode").value.trim().toUpperCase();
  const nama = $("dmsEditNama").value.trim().toUpperCase();
  const index = parseInt($("dmsEditIndex").value, 10), isNew = index === -1;
  clearFieldErrors();
  let ok = true;
  if (!kode) { setFieldError("ferrKode", "Kode wajib diisi"); ok = false; }
  if (!nama) { setFieldError("ferrNama", "Nama pabrik wajib diisi"); ok = false; }
  if (!ok) return;
  const next = dmsList.map(r => [...r]);
  if (isNew) next.push([kode, nama]); else next[index] = [kode, nama];
  const btn = $("dmsEditConfirm"); if (btn.disabled) return; setBusy(btn, true);
  const saved = await commitDms(next);
  setBusy(btn, false);
  if (!saved) return;
  pushHistory(isNew ? "tambah" : "edit", "DMS", `${kode} · ${nama}`);
  toast(isNew ? `Pabrik ditambahkan: ${kode}` : `Pabrik diperbarui: ${kode}`, "success");
  closeModal("dmsEditModal"); renderDmsTable();
}

/* ---------- ID BTB DMS Counter PRG (tambah / edit / hapus oleh admin) ---------- */
function renderBtbTable() {
  const tbody = document.querySelector("#btbTable tbody"); if (!tbody) return;
  tbody.innerHTML = "";
  btbList.forEach((row, i) => {
    const tr = document.createElement("tr");
    tr.className = "dms-row"; tr.style.animationDelay = 18 * i + "ms";
    tr.innerHTML = `
        <td class="dms-td-kode"><span class="kode-chip">${esc(row[0])}</span></td>
        <td class="dms-td-nama">${esc(row[1])}</td>
        ${isAdmin ? `<td class="td-act"><div class="act-group">
          <button class="act-btn act-edit" data-i="${i}" aria-label="Edit" title="Edit"><i class="fas fa-pen-to-square"></i><span>Edit</span></button>
          <button class="act-btn act-del" data-i="${i}" aria-label="Hapus" title="Hapus"><i class="fas fa-trash-can"></i><span>Hapus</span></button>
        </div></td>` : ""}`;
    tr.addEventListener("click", e => {
      if (e.target.closest(".act-btn")) return;
      document.querySelectorAll("#btbTable tbody tr.active-row").forEach(t => t.classList.remove("active-row"));
      tr.classList.add("active-row");
      navigator.clipboard?.writeText(row[0]).then(() => toast(`📋 Disalin: ${row[0]} · ${row[1]}`, "info", 2200)).catch(() => {});
    });
    tbody.appendChild(tr);
    requestAnimationFrame(() => tr.classList.add("row-in"));
  });
  if (isAdmin) {
    tbody.querySelectorAll(".act-edit").forEach(b => b.addEventListener("click", e => { e.stopPropagation(); openBtbEdit(+b.dataset.i); }));
    tbody.querySelectorAll(".act-del").forEach(b => b.addEventListener("click", e => { e.stopPropagation(); openDeleteModal("btb", null, +b.dataset.i); }));
  }
  const count = $("btbCount"); if (count) count.textContent = `${btbList.length} counter`;
  const addWrap = $("btbAddWrap"); if (addWrap) addWrap.style.display = isAdmin ? "flex" : "none";
  const headRow = document.querySelector("#btbTable thead tr");
  if (headRow) {
    const existing = headRow.querySelector(".th-act-dms");
    if (isAdmin && !existing) { const th = document.createElement("th"); th.className = "th-act-dms th-act"; th.innerHTML = '<i class="fas fa-sliders"></i>'; headRow.appendChild(th); }
    else if (!isAdmin && existing) existing.remove();
  }
  setupBtbSearch();
  applyBtbFilter();
  refreshOpenAccordionHeight("btbPrg");
}
function applyBtbFilter() {
  const input = $("btbSearch"); if (!input) return;
  const table = $("btbTable"), noResult = $("btbNoResult"), noQuery = $("btbNoResultQuery"), count = $("btbCount"), clearBtn = $("btbSearchClear");
  const q = input.value.toUpperCase().replace(/\s+/g, "");
  let visible = 0;
  table.querySelectorAll("tbody tr").forEach(tr => { const match = tr.textContent.toUpperCase().replace(/\s+/g, "").includes(q); tr.style.display = match ? "" : "none"; if (match) visible++; });
  if (clearBtn) clearBtn.style.display = q ? "flex" : "none";
  if (noResult) { noResult.classList.toggle("hidden", visible > 0 || !q); if (noQuery) noQuery.textContent = input.value; }
  if (count) count.textContent = q ? `${visible} dari ${btbList.length} counter` : `${btbList.length} counter`;
}
function setupBtbSearch() {
  const input = $("btbSearch"), clearBtn = $("btbSearchClear");
  if (!input || input.dataset.ready) return;
  input.dataset.ready = "1";
  input.addEventListener("input", applyBtbFilter);
  clearBtn?.addEventListener("click", () => { input.value = ""; applyBtbFilter(); input.focus(); });
}
function openBtbEdit(index) {
  const isNew = index === -1;
  const row = isNew ? ["", ""] : btbList[index];
  const title = $("btbEditTitle"); if (title) title.innerHTML = isNew ? '<i class="fas fa-circle-plus"></i> Tambah Counter' : '<i class="fas fa-pen-to-square"></i> Edit Counter';
  $("btbEditId").value = row[0]; $("btbEditNama").value = row[1]; $("btbEditIndex").value = index;
  clearFieldErrors(); openModal("btbEditModal");
  setTimeout(() => $("btbEditId")?.focus(), 230);
}
async function submitBtbEdit() {
  const id = fixBtbId($("btbEditId").value.trim().toUpperCase());
  const nama = $("btbEditNama").value.trim().toUpperCase();
  const index = parseInt($("btbEditIndex").value, 10), isNew = index === -1;
  clearFieldErrors();
  let ok = true;
  if (!id) { setFieldError("ferrBtbId", "ID wajib diisi"); ok = false; }
  if (!nama) { setFieldError("ferrBtbNama", "Nama counter wajib diisi"); ok = false; }
  if (!ok) return;
  if (btbList.some((r, i) => r[0] === id && i !== index)) { setFieldError("ferrBtbId", "ID ini sudah ada"); return; }
  const next = btbList.map(r => [...r]);
  if (isNew) next.push([id, nama]); else next[index] = [id, nama];
  const btn = $("btbEditConfirm"); if (btn.disabled) return; setBusy(btn, true);
  const saved = await commitBtb(next);
  setBusy(btn, false);
  if (!saved) return;
  pushHistory(isNew ? "tambah" : "edit", "BTB COUNTER", `${id} · ${nama}`);
  toast(isNew ? `Counter ditambahkan: ${id}` : `Counter diperbarui: ${id}`, "success");
  closeModal("btbEditModal"); renderBtbTable();
}

/* ---------- Admin login / countdown ---------- */
/* Proteksi tambahan di sisi klien: setelah beberapa kali gagal, tombol login
   dikunci sementara. Ini lapisan kedua saja — Firebase Auth sendiri sudah
   punya rate-limit bawaan (auth/too-many-requests) di sisi server. */
let loginFailCount = 0;
let loginLockUntil = 0;
const LOGIN_MAX_ATTEMPTS = 5;
const LOGIN_LOCK_MS = 30000;

async function submitAdminLogin() {
  const now = Date.now();
  if (now < loginLockUntil) {
    const secsLeft = Math.ceil((loginLockUntil - now) / 1000);
    const err = $("adminError");
    if (err) { err.textContent = `Terlalu banyak percobaan. Coba lagi dalam ${secsLeft} detik.`; err.style.display = "flex"; }
    return;
  }
  const email = $("adminEmailInput").value.trim(), pass = $("adminPassInput").value.trim();
  const err = $("adminError"); if (err) err.textContent = "";
  if (!email || !pass) { if (!email) setFieldError("ferrEmail", "Email wajib diisi"); if (!pass) setFieldError("ferrPass", "Password wajib diisi"); return; }
  store.set("ur_keep", $("adminKeep")?.checked ? "1" : "0");
  const okBtn = $("adminConfirm"), okHtml = okBtn ? okBtn.innerHTML : "";
  if (okBtn) { okBtn.disabled = true; okBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memeriksa…'; }
  try {
    if (!auth) throw { code: "auth/offline" };
    await signInWithEmailAndPassword(auth, email, pass);
    loginFailCount = 0;
    store.set("ur_email", email);
    closeModal("adminModal"); toast("✦ Login berhasil!", "success");
  } catch (e) {
    loginFailCount++;
    let msg = "Email atau password salah";
    if (e.code === "auth/offline" || e.code === "auth/network-request-failed") msg = "Tidak ada koneksi internet. Login admin butuh online.";
    if (e.code === "auth/too-many-requests") msg = "Terlalu banyak percobaan gagal. Coba lagi beberapa saat lagi.";
    if (loginFailCount >= LOGIN_MAX_ATTEMPTS) {
      loginLockUntil = Date.now() + LOGIN_LOCK_MS;
      msg = `Terlalu banyak percobaan. Form dikunci ${LOGIN_LOCK_MS / 1000} detik.`;
      loginFailCount = 0;
    }
    if (err) { err.textContent = msg; err.style.display = "flex"; }
    const box = $("adminModal")?.querySelector(".modal-box");
    if (box) { box.classList.add("modal-shake"); setTimeout(() => box.classList.remove("modal-shake"), 450); }
    toast(msg, "error");
  } finally {
    if (okBtn) { okBtn.disabled = false; okBtn.innerHTML = okHtml; }
  }
}
function renderAdminKeep() {
  const btn = $("adminBtn"); if (!btn || !isAdmin) return;
  btn.classList.remove("countdown"); btn.classList.add("admin-on");
  btn.innerHTML = '<i class="fas fa-lock-open"></i>';
  const cap = $("adminCaption"); if (cap) cap.textContent = "Admin aktif · keluar";
}
function renderAdminButton() {
  const btn = $("adminBtn"); if (!btn || !isAdmin) return;
  btn.classList.add("countdown");
  const cap = $("adminCaption"); if (cap) cap.textContent = "Admin aktif · keluar";
  const mm = Math.floor(logoutSeconds / 60), ss = logoutSeconds % 60;
  const dashOffset = 276 - (logoutSeconds / 300) * 276;
  btn.innerHTML = `<svg class="timer-ring" viewBox="0 0 100 100">
      <circle cx="50" cy="50" r="44" fill="none" stroke="rgba(255,69,96,0.18)" stroke-width="8"/>
      <circle cx="50" cy="50" r="44" fill="none" stroke="#ff4560" stroke-width="8"
        stroke-dasharray="276" stroke-dashoffset="${dashOffset}"
        stroke-linecap="round" transform="rotate(-90 50 50)"
        style="transition:stroke-dashoffset 0.95s linear"/>
    </svg><span class="timer-text">${mm}:${ss.toString().padStart(2, "0")}</span>`;
}

/* ---------- History modal ---------- */
function renderHistoryList() {
  const el = $("historyList"); if (!el) return;
  if (!historyList.length) { el.innerHTML = '<div class="hist-empty"><i class="fas fa-inbox"></i><p>Belum ada histori</p></div>'; return; }
  const icons = { tambah: "<i class='fas fa-plus-circle' style='color:#00e676'></i>", edit: "<i class='fas fa-pen-to-square' style='color:#ffc107'></i>", hapus: "<i class='fas fa-trash-can' style='color:#ff4560'></i>" };
  const labels = { tambah: "Tambah", edit: "Edit", hapus: "Hapus" };
  el.innerHTML = historyList.map(h => {
    const time = new Date(h.ts).toLocaleString("id-ID", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
    return `<div class="hist-item">
        <div class="hist-action">${icons[h.action] || "•"} <span class="hist-badge hist-${h.action}">${labels[h.action] || h.action}</span></div>
        <div class="hist-detail">${esc(h.detail)}</div>
        <div class="hist-meta"><span class="hist-section">${esc(h.section)}</span> · <span class="hist-time">${time}</span></div>
      </div>`;
  }).join("");
}

/* ---------- Chat widget ---------- */
function initChat() {
  const toggle = $("chatToggle"), box = $("chatBox"), closeBtn = $("chatClose"), waLink = $("chatWA");
  const typingEl = $("typing"), bubbles = document.querySelectorAll(".bubble.bot"), sound = $("chatSound"), badge = document.querySelector(".chat-notif");
  const playSequence = () => {
    bubbles.forEach(b => b.classList.add("hidden")); typingEl?.classList.add("hidden"); waLink?.classList.add("hidden");
    let delay = 600;
    bubbles.forEach(b => {
      setTimeout(() => {
        typingEl?.classList.remove("hidden");
        setTimeout(() => { typingEl?.classList.add("hidden"); b.classList.remove("hidden"); if (sound) { sound.currentTime = 0; sound.play().catch(() => {}); } }, 700);
      }, delay);
      delay += 1400;
    });
    setTimeout(() => waLink?.classList.remove("hidden"), delay + 200);
  };
  toggle?.addEventListener("click", () => {
    if (box.classList.toggle("show")) { if (badge) badge.style.display = "none"; if (!chatOpened) { chatOpened = true; playSequence(); } }
  });
  closeBtn?.addEventListener("click", () => box.classList.remove("show"));
  document.addEventListener("click", e => { if (box?.classList.contains("show") && !box.contains(e.target) && !toggle.contains(e.target)) box.classList.remove("show"); });
}


/* ---------- Filter nav (kartu ritase) ---------- */
function initFilterNav() {
  const btns = document.querySelectorAll(".filter-btn"), cards = document.querySelectorAll(".acc-item[data-category]");
  btns.forEach(btn => btn.addEventListener("click", () => {
    btns.forEach(b => b.classList.remove("active")); btn.classList.add("active");
    const f = btn.dataset.filter;
    cards.forEach(c => { c.style.display = (f === "all" || (c.dataset.category || "").includes(f)) ? "" : "none"; });
    if (window.urSyncCols) window.urSyncCols();
  }));
}
function initSortButtons() {
  document.querySelectorAll(".card-sort").forEach(btn => {
    const target = btn.dataset.target; sortState[target] = "none";
    btn.addEventListener("click", () => {
      const key = camel(target);
      if (sortState[target] !== "asc") { ritase[key].sort((a, b) => a[2] - b[2]); sortState[target] = "asc"; btn.classList.add("asc"); btn.classList.remove("desc"); }
      else { ritase[key].sort((a, b) => b[2] - a[2]); sortState[target] = "desc"; btn.classList.add("desc"); btn.classList.remove("asc"); }
      renderRitaseTable(target, ritase[key]);
    });
  });
}

/* ---------- ACCORDION: menu data lainnya (lazy render saat dibuka) ---------- */
const accRendered = {};
function initAccordion() {
  document.querySelectorAll(".acc-item").forEach(item => {
    const key = item.dataset.acc;
    const head = item.querySelector(".acc-head");
    const body = item.querySelector(".acc-body");
    head.addEventListener("click", () => {
      const opening = !item.classList.contains("acc-open");
      item.classList.toggle("acc-open", opening);
      head.setAttribute("aria-expanded", opening ? "true" : "false");
      if (opening) {
        if (!accRendered[key]) { renderAccordionContent(key); accRendered[key] = true; }
        body.style.maxHeight = body.scrollHeight + "px";
      } else {
        body.style.maxHeight = "0px";
      }
    });
  });
}
function renderAccordionContent(key) {
  if (key === "dmsPabrik") { renderDmsTable(); }
  if (key === "btbPrg") { renderBtbTable(); }
  if (key === "refKode") { initRefTabs(); }
}
// re-measure open accordion height after its content re-renders (search, edit, dll)
function refreshOpenAccordionHeight(key) {
  const item = document.querySelector(`.acc-item[data-acc="${key}"]`);
  if (item && item.classList.contains("acc-open")) {
    const body = item.querySelector(".acc-body");
    requestAnimationFrame(() => { body.style.maxHeight = body.scrollHeight + "px"; });
  }
}

/* ---------- Tabel referensi (sub-tab di dalam accordion refKode) ---------- */
function initRefTabs() {
  const tabsWrap = $("refTabs"), panelsWrap = $("refPanels");
  if (!tabsWrap || !panelsWrap) return;
  const keys = Object.keys(REF_DATA);
  tabsWrap.innerHTML = keys.map((k, i) => `<button class="ref-tab-btn${i === 0 ? " active" : ""}" data-ref="${k}"><i class="fas ${REF_DATA[k].icon}"></i> ${REF_DATA[k].label}</button>`).join("");
  panelsWrap.innerHTML = keys.map((k, i) => {
    const d = REF_DATA[k];
    const rowsHtml = d.rows.map((r, ri) => `<tr><td>${ri + 1}. ${esc(r[0])}</td><td>${r[1]}</td></tr>`).join("");
    return `<div class="ref-panel${i === 0 ? " active" : ""}" data-panel="${k}">
        <div class="table-container"><table class="ref-table">
          <thead><tr><th>${esc(d.cols[0])}</th><th>${esc(d.cols[1])}</th></tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table></div>
      </div>`;
  }).join("") + `<p class="ref-empty" style="text-align:left;padding:10px 2px 0"><i class="fas fa-circle-info"></i> ${REF_NOTE}</p>`;

  tabsWrap.querySelectorAll(".ref-tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      tabsWrap.querySelectorAll(".ref-tab-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      panelsWrap.querySelectorAll(".ref-panel").forEach(p => p.classList.toggle("active", p.dataset.panel === btn.dataset.ref));
      refreshOpenAccordionHeight("refKode");
    });
  });
  refreshOpenAccordionHeight("refKode");
}

/* ---------- Datetime pill & visitor counter ---------- */
function initClock() {
  const el = $("datetime"); if (!el) return;
  const tick = () => { el.textContent = new Date().toLocaleString("id-ID", { weekday: "short", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", second: "2-digit" }) + " WIB"; };
  tick(); setInterval(tick, 1000);
}
function initVisitorCounter() {
  let total = (parseInt(store.get("visCount") || "1540", 10) || 1540) + 1;
  store.set("visCount", total);
  const el = $("visitorNumber"); if (!el) return;
  let n = total - 20;
  const step = () => { n++; el.textContent = n; if (n < total) requestAnimationFrame(step); };
  requestAnimationFrame(step);
}

/* ---------- Reveal on scroll (murah: sekali per elemen) ---------- */
function initRevealOnScroll() {
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.style.opacity = "1"; e.target.style.transform = "translateY(0)"; io.unobserve(e.target); } });
  }, { threshold: 0.08 });
  document.querySelectorAll(".glass-card, .stats-bar").forEach(el => { io.observe(el); });
}

/* ---------- Window resize: cek scrollable ritase-table ---------- */
window.addEventListener("resize", () => {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { document.querySelectorAll(".rtw").forEach(w => w.classList.toggle("scrollable", w.scrollWidth > w.clientWidth + 2)); }, 200);
}, { passive: true });

/* ---------- Firebase listeners ---------- */
function startListeners() {
  /* status koneksi server (untuk lencana Online / Offline di atas) */
  onValue(ref(db, ".info/connected"), snap => {
    window.dispatchEvent(new CustomEvent("ur:conn", { detail: { server: !!snap.val() } }));
  });
  onValue(ref(db, "ritase"), snap => {
    const v = snap.val(), has = v && typeof v === "object";
    ["spsAqua", "galonAqua", "spsVit", "galonVit"].forEach(k => {
      ritase[k] = has ? fromObj(v[k]) : DEFAULT_RITASE[k].map(r => [...r]);
    });
    gotServer.ritase = true; lastSync = Date.now(); dataSource = "server";
    renderAllRitase(); saveCache(); announce("server");
  }, err => { toast("Gagal membaca data: " + err.message, "error", 6000); });
  onValue(ref(db, "dms"), snap => {
    const arr = fromObj(snap.val());
    dmsList = arr.length ? arr : DEFAULT_DMS.map(r => [...r]);
    gotServer.dms = true;
    if (accRendered.dmsPabrik) renderDmsTable();
    saveCache();
  });
  onValue(ref(db, "btb"), snap => {
    const arr = fromObj(snap.val());
    btbList = (arr.length ? arr : DEFAULT_BTB).map(r => [fixBtbId(r[0]), r[1]]);
    gotServer.btb = true;
    if (accRendered.btbPrg) renderBtbTable();
    saveCache();
  }, () => { if (!btbList.length) btbList = DEFAULT_BTB.map(r => [...r]); if (accRendered.btbPrg) renderBtbTable(); });
  onAuthStateChanged(auth, onAuth);
}
const gotServer = { ritase: false, dms: false, btb: false };
let histOff = null;
function syncHistory(user) {
  if (histOff) { histOff(); histOff = null; }
  if (!user) { historyList = []; renderHistoryList(); return; }
  histOff = onValue(ref(db, "history"), snap => {
    const v = snap.val();
    historyList = v ? Object.entries(v).map(([id, h]) => ({ id, ...h })).sort((a, b) => b.ts - a.ts).slice(0, 50) : [];
    renderHistoryList();
  }, () => {});
}
function onAuth(user) {
  isAdmin = !!user;
  document.body.classList.toggle("admin-mode", isAdmin);
  syncHistory(user);
  const histBtn = $("histBtn"); if (histBtn) histBtn.style.display = isAdmin ? "flex" : "none";
  const adminBtn = $("adminBtn");
  if (adminBtn) {
    if (isAdmin) {
      clearInterval(logoutTimer);
      if (store.get("ur_keep") === "1") { renderAdminKeep(); }
      else {
        logoutSeconds = 300; renderAdminButton();
        logoutTimer = setInterval(() => { if (!document.querySelector("#rowEditModal.modal-open,#dmsEditModal.modal-open,#btbEditModal.modal-open,#deleteModal.modal-open")) logoutSeconds--; renderAdminButton(); if (logoutSeconds <= 0) { clearInterval(logoutTimer); if (signOut && auth) signOut(auth); } }, 1000);
      }
    } else {
      clearInterval(logoutTimer); adminBtn.classList.remove("countdown", "admin-on"); adminBtn.innerHTML = '<i class="fas fa-lock"></i>'; { const cap = $("adminCaption"); if (cap) cap.textContent = "Rubah/Edit/Hapus"; }
    }
  }
  renderAllRitase();
  if (accRendered.dmsPabrik) renderDmsTable();
  if (accRendered.btbPrg) renderBtbTable();
}

/* Tabel langsung tampil dari salinan terakhir (cepat & bisa offline),
   lalu diperbarui begitu server menjawab. */
function bootData() {
  if (loadCache()) { renderAllRitase(); announce("cache"); }
  /* belum ada salinan sama sekali + server tak menjawab → pakai data bawaan supaya tidak kosong */
  setTimeout(() => {
    if (gotServer.ritase || dataSource === "cache") return;
    Object.keys(DEFAULT_RITASE).forEach(k => { ritase[k] = DEFAULT_RITASE[k].map(r => [...r]); });
    if (!dmsList.length) dmsList = DEFAULT_DMS.map(r => [...r]);
    if (!btbList.length) btbList = DEFAULT_BTB.map(r => [...r]);
    dataSource = "default"; renderAllRitase(); announce("default");
  }, 6000);
  /* dms/btb belum ada dari server & belum ada cache → isi bawaan saat dibuka */
  if (!dmsList.length) dmsList = DEFAULT_DMS.map(r => [...r]);
  if (!btbList.length) btbList = DEFAULT_BTB.map(r => [...r]);
  loadFirebase().then(startListeners).catch(err => {
    if (window.console) console.warn("[UangRitase] Firebase tidak termuat (offline?):", err && err.message);
    window.dispatchEvent(new CustomEvent("ur:conn", { detail: { server: false, failed: true } }));
  });
}

/* ---------- Init ---------- */
document.addEventListener("DOMContentLoaded", () => {
  initClock();
  initVisitorCounter();
  initFilterNav();
  initSortButtons();
  initAccordion();
  initChat();
  initRevealOnScroll();

  $("adminPassToggle")?.addEventListener("click", () => {
    const input = $("adminPassInput"); const wasHidden = input.type === "password";
    input.type = wasHidden ? "text" : "password";
    $("adminPassToggle").innerHTML = wasHidden ? '<i class="fas fa-eye-slash"></i>' : '<i class="fas fa-eye"></i>'; $("adminPassToggle").setAttribute("aria-label", wasHidden ? "Sembunyikan password" : "Tampilkan password");
  });
  $("adminBtn")?.addEventListener("click", () => {
    if (isAdmin) { store.del("ur_keep"); if (signOut && auth) signOut(auth); toast("Logout berhasil", "info"); return; }
    $("adminEmailInput").value = store.get("ur_email") || ""; $("adminPassInput").value = "";
    if ($("adminKeep")) $("adminKeep").checked = store.get("ur_keep") === "1";
    const err = $("adminError"); if (err) err.textContent = "";
    clearFieldErrors(); openModal("adminModal");
    setTimeout(() => ($("adminEmailInput").value ? $("adminPassInput") : $("adminEmailInput"))?.focus(), 240);
  });
  $("adminXClose")?.addEventListener("click", () => closeModal("adminModal"));
  $("adminCancel")?.addEventListener("click", () => closeModal("adminModal"));
  $("adminConfirm")?.addEventListener("click", submitAdminLogin);
  [$("adminEmailInput"), $("adminPassInput")].forEach(el => el?.addEventListener("keydown", e => { if (e.key === "Enter") submitAdminLogin(); }));
  $("adminPassInput")?.addEventListener("keyup", e => { const w = $("capsWarn"); if (w && e.getModifierState) w.classList.toggle("on", e.getModifierState("CapsLock")); });
  $("adminPassInput")?.addEventListener("blur", () => $("capsWarn")?.classList.remove("on"));
  $("adminModal")?.addEventListener("click", e => { if (e.target === $("adminModal")) closeModal("adminModal"); });

  $("deleteConfirm")?.addEventListener("click", confirmDelete);
  $("deleteCancel")?.addEventListener("click", () => { closeModal("deleteModal"); deleteCtx = null; });
  $("deleteModal")?.addEventListener("click", e => { if (e.target === $("deleteModal")) { closeModal("deleteModal"); deleteCtx = null; } });

  $("rowEditX")?.addEventListener("click", () => { closeModal("rowEditModal"); editCtx = null; clearFieldErrors(); });
  $("rowEditCancel")?.addEventListener("click", () => { closeModal("rowEditModal"); editCtx = null; clearFieldErrors(); });
  $("rowEditConfirm")?.addEventListener("click", submitRowEdit);
  $("rowEditHarga")?.addEventListener("keydown", e => { if (e.key === "Enter") submitRowEdit(); });
  $("rowEditModal")?.addEventListener("click", e => { if (e.target === $("rowEditModal")) { closeModal("rowEditModal"); editCtx = null; clearFieldErrors(); } });

  $("dmsEditX")?.addEventListener("click", () => closeModal("dmsEditModal"));
  $("dmsEditCancel")?.addEventListener("click", () => closeModal("dmsEditModal"));
  $("dmsEditConfirm")?.addEventListener("click", submitDmsEdit);
  ["dmsEditKode", "dmsEditNama"].forEach(id => $(id)?.addEventListener("keydown", e => { if (e.key === "Enter") submitDmsEdit(); }));
  $("dmsEditModal")?.addEventListener("click", e => { if (e.target === $("dmsEditModal")) closeModal("dmsEditModal"); });
  $("dmsAddBtn")?.addEventListener("click", () => openDmsEdit(-1));
  $("btbEditX")?.addEventListener("click", () => closeModal("btbEditModal"));
  $("btbEditCancel")?.addEventListener("click", () => closeModal("btbEditModal"));
  $("btbEditConfirm")?.addEventListener("click", submitBtbEdit);
  ["btbEditId", "btbEditNama"].forEach(id => $(id)?.addEventListener("keydown", e => { if (e.key === "Enter") submitBtbEdit(); }));
  $("btbEditModal")?.addEventListener("click", e => { if (e.target === $("btbEditModal")) closeModal("btbEditModal"); });
  $("btbAddBtn")?.addEventListener("click", () => openBtbEdit(-1));

  $("histBtn")?.addEventListener("click", () => openModal("historyModal"));
  $("adminCaption")?.addEventListener("click", () => $("adminBtn")?.click());
  $("historyClose")?.addEventListener("click", () => closeModal("historyModal"));
  $("historyModal")?.addEventListener("click", e => { if (e.target === $("historyModal")) closeModal("historyModal"); });

  document.querySelectorAll(".glass-card").forEach((c, i) => { c.style.animationDelay = 0.07 * i + "s"; });
  bootData();
});
